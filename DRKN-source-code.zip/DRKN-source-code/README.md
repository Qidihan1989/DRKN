# Official Pytorch implementation for reproducing the results of Deep Randomized Kernel Network.

The repository contains code for reproducing experiments of Deep Randomized Kernel Networks(DRKN).

### Requirements
- python >= 3.6
- pytorch >= 0.4.1
- sklearn, math, numpy, matplotlib,os,torchvision
- machine with CPU for UCI datasets.
- machine with 1 GPU for Cifar10 and SVHN.

### Datasets and experiments setting
The code works with several common datasets. The experiments include
-small scale UCI_datasets: Fertility,Monks1,Monks2,Monks3,Climate,EEG,QSAR,Phishing,Website,Crowd,ShillBidding,Avila
-large scale UCI_datasets: Adult,Covtype
-Image datasets:           MNIST,Cifar10,SVHN

Each of the following scripts contains the experiment setting and the model parameters on respective dataset:

-small scale UCI_datasets
--Fertility:   [script](DRKN-source-code/DRKN/core/param_ops/Fertility.py)
--Monks1:      [script](DRKN-source-code/DRKN/core/param_ops/Monks1.py)
--Monks2:      [script](DRKN-source-code/DRKN/core/param_ops/Monks2.py)
--Monks3:      [script](DRKN-source-code/DRKN/core/param_ops/Monks3.py)
--Climate:     [script](DRKN-source-code/DRKN/core/param_ops/Climate.py)
--EEG:         [script](DRKN-source-code/DRKN/core/param_ops/EEG.py)
--QSAR:        [script](DRKN-source-code/DRKN/core/param_ops/QSAR.py)
--Phishing:    [script](DRKN-source-code/DRKN/core/param_ops/Phishing.py)
--Website:     [script](DRKN-source-code/DRKN/core/param_ops/Website.py)
--Crowd:       [script](DRKN-source-code/DRKN/core/param_ops/Crowd.py)
--ShillBidding:[script](DRKN-source-code/DRKN/core/param_ops/ShillBidding.py)
--Avila:       [script](DRKN-source-code/DRKN/core/param_ops/Avila.py)

-large scale UCI_datasets:
--Adult:       [script](DRKN-source-code/DRKN/core/param_ops/Adult.py)
--Covtype:     [script](DRKN-source-code/DRKN/core/param_ops/Covtype.py)


### Running the code

The [script](DRKN-source-code/DRKN/DRKN-fc-toy_function.py) launches the experiments of DRKN-fc on toy functions.
The [script](DRKN-source-code/DRKN/DRKN-fc-UCI.py) launches the training and testing of DRKN-fc on UCI datasets.
The [script](DRKN-source-code/DRKN/DRKN-fc-MNIST.py) launches the experiments of DRKN-fc and DNN on MNIST datasets.
The [script](DRKN-source-code/DRKN/DRKN-conv-CIFAR10.py) launches the training and testing of DRKN-conv on CIFAR10 datasets.



