"""
classes: DRKN-fc,DRKN-conv
"""
import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math


class rff_layer(nn.Module):
    def __init__(self,data_batch,input_dim,encoder_dim,non_linear_dim,kernel_approximation='Gaussian'):
        super (rff_layer,self).__init__()
        self.input_dim = input_dim     
        self.encoder_dim = encoder_dim                    
        self.random_feature_dim = data_batch 
        self.non_linear_dim = non_linear_dim
        self.data_batch = data_batch
        self.approximation = kernel_approximation
        self.batchnorm_ecoder = nn.BatchNorm1d(encoder_dim)
        self.batchnorm = nn.BatchNorm1d(self.non_linear_dim)
        self.batchnorm2 = nn.BatchNorm1d(self.random_feature_dim)
        self.non_linear_mapping = nn.Linear(self.input_dim,self.non_linear_dim) 
        self.encoder_layer_weight_inital()   
        
    def encoder_layer_weight_inital(self,):
        self.fc1_w = nn.Linear(self.input_dim, self.encoder_dim)
        self.fc2_w = nn.Linear(self.encoder_dim, self.non_linear_dim)
        self.fc3_w = nn.Linear(self.encoder_dim, self.non_linear_dim)
        self.centered_isotropic_Gaussian = torch.randn(self.random_feature_dim,self.non_linear_dim)
        self.eps = self.xavier_normal_(self.centered_isotropic_Gaussian)
        nn.init.kaiming_normal_(self.fc1_w.weight.data)
        nn.init.kaiming_normal_(self.fc2_w.weight.data)
        nn.init.kaiming_normal_(self.fc3_w.weight.data)
        nn.init.kaiming_normal_(self.non_linear_mapping.weight.data)
        

    def mu_sigma_encoder(self,x):
        h = F.relu(self.batchnorm_ecoder(self.fc1_w(x)))
        mu,sigma = self.fc2_w(h),self.fc3_w(h)
        return mu,sigma
    
    
    def _calculate_fan_in_and_fan_out(self,tensor):
        dimensions = tensor.dim()
        if dimensions < 2:
            raise ValueError("Fan in and fan out can not be computed for tensor with fewer than 2 dimensions")
        num_input_fmaps = tensor.size(1)
        num_output_fmaps = tensor.size(0)
        receptive_field_size = 1
        if tensor.dim() > 2:
            for s in tensor.shape[2:]:
                receptive_field_size *= s
        fan_in = num_input_fmaps * receptive_field_size
        fan_out = num_output_fmaps * receptive_field_size
        return fan_in, fan_out
    
    def _no_grad_normal_(self,tensor, mean, std):
        with torch.no_grad():
            normal_tensor = tensor.normal_(mean, std)
            return normal_tensor
    
    def xavier_normal_(self,tensor, gain: float = 1.):
        fan_in, fan_out = self._calculate_fan_in_and_fan_out(tensor)
        std = gain * math.sqrt(2.0 / float(fan_in + fan_out))
        inital_res = self._no_grad_normal_(tensor, 0., std)
        return inital_res
       
    def reparameterize(self,mu,log_var):
        sigma = torch.exp(log_var / 2)
        res = mu + self.eps * sigma
        return res

    def _KL_loss(self,mu,log_var):
        return  0.5 * torch.sum( mu.pow(2) + torch.exp(log_var) -1 - log_var)/(self.data_batch)
  
    def NonLinear_Module(self,x):
        x = self.non_linear_mapping(x)
        x = torch.relu(x)
        return x
    
    def Sampling_Module(self,x):
        mu, log_var = self.mu_sigma_encoder(x)
        w = self.reparameterize(mu, log_var)
        layer_loss = self._KL_loss(mu,log_var) 
        return w,layer_loss
    
    def RandomFeature_Module(self,x,w):
        if self.approximation =='Gaussian':
            cos_z = torch.cos(torch.matmul(x,w))
        else:
            cos_z = torch.relu(torch.matmul(x,w))
            cos_z = self.batchnorm2(cos_z)
        return cos_z
    
    def forward(self, x):
        w,layer_loss = self.Sampling_Module(x)
        self.w =w
        x_ = self.NonLinear_Module(x) 
        feature = self.RandomFeature_Module(x_,w.t())##w.t() 【input_dim,data_num=random_feature_dim】
        self.layer_Gram_matrix = torch.matmul(feature,feature.t())
        self.show_feature = feature
        return  feature,layer_loss
    
    def pred(self,x):
        x_ = self.NonLinear_Module(x)
        feature = self.RandomFeature_Module(x_,self.w.t())##w.t() 【input_dim,data_num=random_feature_dim】
        return feature
        
class RFF_net(nn.Module):
    def __init__(self,data_batch,input_dim,out_dim,h_dim,layer_num,kernel_approximation ='Gaussian'):
        super(RFF_net,self).__init__()
        self.input_dim = input_dim
        self.h_dim = h_dim             
        self.out_dim = out_dim
        self.random_feature_dim = data_batch 
        self.data_batch = data_batch
        self.layer_num = layer_num
        self.approximation = kernel_approximation
        self.names = self.__dict__['_modules']
        self.rff_net = nn.Sequential()
        self.rff_net_initial()
        
    def rff_net_initial(self,):
        self.layer_construction()
        nn.init.kaiming_normal_(self.output_layer.weight.data)
              
    def layer_construction(self,):
        self.rff_1 = rff_layer(self.data_batch,self.input_dim,self.out_dim,self.h_dim,self.approximation)
        
        if self.layer_num > 1:
            for i in range(1,self.layer_num):
                name = 'rff_'+str(i+1)
                self.rff_net.add_module(name,rff_layer(int(self.data_batch),int(self.data_batch),self.out_dim,self.h_dim,self.approximation))        
        self.output_layer = nn.Linear(int(self.data_batch), self.out_dim)#outputlayer
        
    def classifier(self, z):
        out = self.output_layer(z)
        out = F.log_softmax(out,dim=1)
        return out
    
    def _layer_cache(self,x):  
        sum_layer_loss = 0
        res_,layer_1_loss= self.rff_1(x)
        sum_layer_loss += layer_1_loss
        for i in range(self.layer_num-1):
            res_,i_layer_loss =  self.rff_net[i](res_)
            sum_layer_loss += i_layer_loss
        sum_layer_loss /= self.layer_num
        return res_,sum_layer_loss
               
    def forward(self,x):
        feature , loss= self._layer_cache(x)
        pred_y = self.classifier(feature)
        return pred_y,loss 


class rff_Cov_layer(nn.Module):
    def __init__(self,data_batch,input_feature,h_dim,conv_param,device,kernel_approximation='Gaussian'):
        super (rff_Cov_layer,self).__init__()
        self.device = device
        self.input_feature = input_feature
        self.h_dim = h_dim                    
        self.data_batch = data_batch
        self.approximation = kernel_approximation
        self.conv_param = conv_param
        self.F,self.C,self.HH,self.WW = self.conv_param['F'],self.conv_param['C'],self.conv_param['H'],self.conv_param['W']
        self.random_feature_dim = int(self.F*self.F*5*5/self.data_batch) 
        self.stride = self.conv_param['stride']
        self.pad = self.conv_param['pad']
        self.bias = self.conv_param['bias']
        self.input_dim = self.C*input_feature*input_feature
        self.batchnorm = nn.BatchNorm2d(self.F)
        self.batchnorm_ecoder = nn.BatchNorm1d(self.h_dim)
        
        self.non_linear_mapping = nn.Conv2d(self.C,self.F,(self.HH,self.WW),self.stride,self.pad,bias=self.bias) 
        self.pooling = nn.MaxPool2d((5,5),1,2)   
        self.encoder_layer_weight_inital()                               
  

    def encoder_layer_weight_inital(self,):
        self.fc1_w = nn.Linear(self.input_dim, self.h_dim)
        self.fc2_w = nn.Linear(self.h_dim, self.random_feature_dim)
        self.fc3_w = nn.Linear(self.h_dim, self.random_feature_dim)
        
        self.centered_isotropic_Gaussian = torch.randn(self.data_batch,self.random_feature_dim).to(self.device)
        self.eps = self.xavier_normal_(self.centered_isotropic_Gaussian)
        
        nn.init.kaiming_normal_(self.fc1_w.weight.data)
        nn.init.kaiming_normal_(self.fc2_w.weight.data)
        nn.init.kaiming_normal_(self.fc3_w.weight.data)
        nn.init.kaiming_normal_(self.non_linear_mapping.weight.data)

    def mu_sigma_encoder(self,x):
        x = x.reshape(self.data_batch,self.input_dim)
        h = F.relu(self.batchnorm_ecoder(self.fc1_w(x)))
        mu,sigma = self.fc2_w(h),self.fc3_w(h)
        x = x.reshape(self.data_batch,self.C,self.input_feature,self.input_feature)
        return mu,sigma
    
    
    def _calculate_fan_in_and_fan_out(self,tensor):
        dimensions = tensor.dim()
        if dimensions < 2:
            raise ValueError("Fan in and fan out can not be computed for tensor with fewer than 2 dimensions")

        num_input_fmaps = tensor.size(1)
        num_output_fmaps = tensor.size(0)
        receptive_field_size = 1
        if tensor.dim() > 2:
            for s in tensor.shape[2:]:
                receptive_field_size *= s
        fan_in = num_input_fmaps * receptive_field_size
        fan_out = num_output_fmaps * receptive_field_size
        return fan_in, fan_out
    
    def _no_grad_normal_(self,tensor, mean, std):
        with torch.no_grad():
            normal_tensor = tensor.normal_(mean, std)
            return normal_tensor
    
    def xavier_normal_(self,tensor, gain: float = 1.):
        fan_in, fan_out = self._calculate_fan_in_and_fan_out(tensor)
        std = gain * math.sqrt(2.0 / float(fan_in + fan_out))
        inital_res = self._no_grad_normal_(tensor, 0., std)
        return inital_res
       
    
    def reparameterize(self,mu,log_var):
        sigma = torch.exp(log_var / 2)
        res = mu + self.eps * sigma
        res = res.reshape(self.F,self.F,5,5)
        return res

    def _KL_loss(self,mu,log_var):
        return  0.5 * torch.sum( mu.pow(2) + torch.exp(log_var) -1 - log_var)/self.data_batch 
    
    
    def conv2d(self,x,weight): 
        stride, pad = 1,2
        n, c, h_in, w_in = x.shape
        d, c, k, j = weight.shape
        x_pad = torch.zeros(n, c, h_in+2*pad, w_in+2*pad).to(self.device)   
        if pad>0:
            x_pad[:, :, pad:-pad, pad:-pad] = x
        else:
            x_pad = x
        x_pad = x_pad.unfold(2, k, stride)
        x_pad = x_pad.unfold(3, j, stride)        
        out = torch.einsum('nchwkj,dckj->ndhw',(x_pad, weight)) 
        return out
    
    
    def NonLinear_Module(self,x):
        x = self.non_linear_mapping(x)
        x = torch.relu(self.batchnorm(x))
        return x
    
    def Sampling_Module(self,x):
        mu, log_var = self.mu_sigma_encoder(x)
        w = self.reparameterize(mu, log_var)
        layer_loss = self._KL_loss(mu,log_var) 
        return w,layer_loss
    
    def RandomFeature_Module(self,x,w):
        if self.approximation =='Gaussian':
            randomfeature = torch.cos(self.batchnorm(self.conv2d(x,w)))
        else:
            randomfeature = torch.relu(self.batchnorm(self.conv2d(x,w)))
        return randomfeature
  
    
    def forward(self, x):
        w,layer_loss = self.Sampling_Module(x)
        w = w.to(self.device)
        self.w = w
        x_ = self.NonLinear_Module(x) 
        feature = self.RandomFeature_Module(x_,w)
        self.cov_feature = feature
        return  feature,layer_loss

class RFF_Cov_net(nn.Module):
    def __init__(self,layer_param_list,batch_size,h_dim,device,kernel_approximation='Gaussian'):
        super(RFF_Cov_net,self).__init__()
        self.device = device
        self.batch_size = batch_size
        self.h_dim = h_dim
        self.kernel_approximation = kernel_approximation
        self.conv_param_1 = layer_param_list[0]
        self.conv_param_2 = layer_param_list[1]
        self.conv_param_3 = layer_param_list[2]
        self.conv_param_4 = layer_param_list[3]
        self.conv_param_5 = layer_param_list[4]
        self.conv_param_6 = layer_param_list[5]
        self.conv_param_7 = layer_param_list[6]
        self.conv_param_8 = layer_param_list[7]
        self.pool1 = nn.MaxPool2d((5,5),1,2)
        self.pool2 = nn.MaxPool2d((5,5),2,2)
        self.batch1 = nn.BatchNorm1d(256)
        self.batch2 = nn.BatchNorm1d(128)
        self.net_construction()
        
    def net_construction(self,):
        self.rff_1 = rff_Cov_layer(self.batch_size,32,self.h_dim,self.conv_param_1,self.device,self.kernel_approximation)
        self.rff_2 = rff_Cov_layer(self.batch_size,32,self.h_dim,self.conv_param_2,self.device,self.kernel_approximation)
        
        self.rff_3 = rff_Cov_layer(self.batch_size,16,self.h_dim,self.conv_param_3,self.device,self.kernel_approximation)
        self.rff_4 = rff_Cov_layer(self.batch_size,16,self.h_dim,self.conv_param_4,self.device,self.kernel_approximation)
        
        self.rff_5 = rff_Cov_layer(self.batch_size,16,self.h_dim,self.conv_param_5,self.device,self.kernel_approximation)
        self.rff_6 = rff_Cov_layer(self.batch_size,16,self.h_dim,self.conv_param_6,self.device,self.kernel_approximation)
        
        self.rff_7 = rff_Cov_layer(self.batch_size,8,self.h_dim,self.conv_param_7,self.device,self.kernel_approximation)
        self.rff_8 = rff_Cov_layer(self.batch_size,8,self.h_dim,self.conv_param_8,self.device,self.kernel_approximation)
        self.fc1 = nn.Linear(64*8*8, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 10)
        
        
    def forward(self,x):
        sum_layer_loss = 0
        feature_,layer_1_loss = self.rff_1(x)
        feature_,layer_2_loss = self.rff_2(feature_)
        feature_ = self.pool2(feature_)
        
        feature_,layer_3_loss = self.rff_3(feature_)
        feature_,layer_4_loss = self.rff_4(feature_)
        feature_ = self.pool1(feature_)
        
        feature_,layer_5_loss = self.rff_5(feature_)
        feature_,layer_6_loss = self.rff_6(feature_)
        feature_ = self.pool2(feature_)
        
        feature_,layer_7_loss = self.rff_7(feature_)
        feature_,layer_8_loss = self.rff_8(feature_)
        feature_ = self.pool1(feature_)
        
        
        res =   feature_.reshape(self.batch_size,-1)
        out = F.relu(self.batch1(self.fc1(res)))
        out = F.relu(self.batch2(self.fc2(out)))
        out = self.fc3(out)
        out = F.log_softmax(out,dim=1)
        sum_layer_loss = layer_1_loss + layer_2_loss +layer_3_loss + layer_4_loss +layer_5_loss + layer_6_loss +layer_7_loss + layer_8_loss 
        loss = sum_layer_loss/8
        return out,loss