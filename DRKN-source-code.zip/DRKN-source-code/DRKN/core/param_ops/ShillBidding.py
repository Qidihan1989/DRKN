"""
ShillBidding dataset class and model parameters

"""

from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torchvision import transforms

class ShillBidding(data.Dataset):
    def __init__(self,root,train = True,):
        self.dir = root
        self.train = train
        self.transforms = transforms
        self.data,self.label = self.get_array(self.dir,self.train,)
    
    
    def get_array(self,root,train): 
        f = open(root)
        data_list = []
        ShillBidding = [] 
        for line in f:
            s = line.strip().split(',')
            data_list.append(s)
        f.close()
        for i in range(1,len(data_list)):
            d=[]
            str_list = data_list[i]
#             print(str_list)
            for i in range(3,len(str_list)):
                d.append(float(str_list[i]))
            ShillBidding.append(d)   
        ShillBidding = np.array(ShillBidding)
#         scaler = preprocessing.StandardScaler()
#         ShillBidding = scaler.fit_transform(ShillBidding)
        ShillBidding = torch.from_numpy(ShillBidding) 
        data_split = int(len(ShillBidding)*0.7)
        if train == True:
            data = ShillBidding[:data_split,:-1]
            label = ShillBidding[:data_split,-1]
        else:
            data = ShillBidding[data_split:,:-1]
            label = ShillBidding[data_split:,-1]
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data,label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data)  
            
cur_dir = os.getcwd()
data_dir = cur_dir+'/data/ShillBidding/ShillBiddingDataset.csv'
epochs = 50
h_dim = 100
batch_size = 100
learning_rate = 1e-3
input_dim = 9
output_dim = 2
layer_num = 2


 
train_dataset = ShillBidding(data_dir,'train')
test_dataset = ShillBidding(data_dir,'test')
param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }