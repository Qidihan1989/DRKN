"""
fertility dataset class and model parameters

"""
from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torch.utils import data

class Fertility(data.Dataset):
    def __init__(self,root,train=True):
        self.dir = root
        self.train = train
        self.data,self.label = self.get_array(self.dir,self.train)
    
    def get_array(self,root,train): 
        f = open(root)
        data_list = []
        fertility = [] 
        for line in f:
            s = line.strip().split(',')
            data_list.append(s)
        f.close()
        for i in range(len(data_list)):
            d=[]
            str_list = data_list[i]
            for i in str_list:
                if i!= 'N'and i!= 'O':
                    d.append(float(i))
                elif i == 'N':
                    d.append(0)
                elif i=='O':
                    d.append(1)
            fertility.append(d)
        fertility = torch.from_numpy(np.array(fertility))    
        data_split = int(len(fertility)*0.7)
        if train == True:
            data = fertility[:data_split,:-1]
            label = fertility[:data_split,-1]
        else:
            data = fertility[data_split:,:-1]
            label = fertility[data_split:,-1]
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data,label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data) 
                 
cur_dir = os.getcwd()
data_dir = cur_dir+'/data/fertilityData/fertility.txt'
train_dataset = Fertility(data_dir,'train')
test_dataset = Fertility(data_dir,'test')
epochs = 2000
h_dim = 100
batch_size = 30
learning_rate = 1e-3
input_dim = 9
output_dim = 2
layer_num = 1

param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }