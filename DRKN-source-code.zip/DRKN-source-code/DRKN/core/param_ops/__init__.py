__all__= ['Adult', 'Avila','CIFAR10','Climate','Covtype','Crowd','EEG','Fertility','MNIST','Monks1','Monks2','Monks3','Phishing','QSAR','ShillBidding','SVHN','Website']
