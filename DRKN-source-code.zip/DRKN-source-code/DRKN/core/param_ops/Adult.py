"""
Adult dataset class and model parameters

"""

from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torchvision import transforms

class Adult(data.Dataset):
    def __init__(self, root,train = True):
        self.dir = root
        self.train = train
        self.data,self.label = self.get_array(self.dir,self.train)
        
    def normalization(self,data):
        _range = torch.max(data,0)[0] - torch.min(data,0)[0]
        res = (data - torch.min(data,0)[0])/_range
        return res
        
    def standardization(self,data):
        mu = torch.mean(data,0)
        sigma = torch.std(data,0)
        res = (data-mu)/sigma
        return res
        
    def get_array(self,root,train):
        f = np.load(root)
        x,y = f["X"],f["Y"]
        data_split = int(x.shape[0]*0.7)
        if train == True:
            data = x[:data_split]
#             data = self.normalization(data)
            label = y[:data_split]
        else:
            data = x[data_split:]
#             data = self.normalization(data)
            label = y[data_split:]
        data = torch.from_numpy(data)
        label = torch.from_numpy(label)
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data, label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data)  
            
            
cur_dir = os.getcwd()
data_dir = cur_dir+'/data/adultData/adult_process.npz'
 


epochs = 1500
h_dim = 100
batch_size = 50
learning_rate = 1e-3
input_dim = 108
output_dim = 2
layer_num = 3

train_dataset = Adult(data_dir,'train')
test_dataset = Adult(data_dir,'test')

param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }

        