"""
SVHN dataset and model parameters
"""
import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math

transform = transforms.Compose(
    [transforms.ToTensor(),]
)
epochs = 50
learning_rate = 2e-4
batch_size=50
input_dim = 32
output_dim = 10
h_dim=100
layer_num = 2

cur_dir = os.getcwd()
data_dir = cur_dir+'/data/SVHN/'
conv_param_1 = {'F':12,'C':3,'H':5,'W':5,'stride':1,'pad':2}
conv_param_2 = {'F':24,'C':12,'H':5,'W':5,'stride':1,'pad':2}


train_dataset = torchvision.datasets.SVHN(root = data_dir, #选择数据的根目录
                           split  = 'train', # 选择训练集
                           transform = transform, #转换成tensor变量
                           download = False) # 不从网络上download图片
test_dataset = torchvision.datasets.SVHN(root = data_dir, #选择数据的根目录
                            split  = 'test', # 选择训练集
                           transform = transform, #转换成tensor变量
                           download = False) # 不从网络上download图片


param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num,
                    'conv_param_1':conv_param_1,
                    'conv_param_2':conv_param_2
                   }
            }

