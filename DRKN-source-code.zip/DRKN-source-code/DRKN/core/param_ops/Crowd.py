"""
Crowd dataset class and model parameters

"""

from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torchvision import transforms


class Crowdsource(data.Dataset):
    def __init__(self,root,train = True):
        self.dir = root
        self.transforms = transforms
        self.train = train
        self.data,self.label = self.get_array(self.dir,self.train)
    
    
    def get_array(self,root,train): 
        f = open(root)
        data_list = []
        Crowdsource = [] 
        for line in f:
            s = line.strip().split(',')
            data_list.append(s)
        f.close()
        for i in range(1,len(data_list)):
            d=[]
            str_list = data_list[i]
            for i in range(1,len(str_list)):
                d.append(float(str_list[i]))
            if str_list[0]=='water':
                d.append(float(0))
            elif str_list[0]=='forest':
                d.append(float(1))
            elif str_list[0]=='impervious':
                d.append(float(2))
            elif str_list[0]=='farm':
                d.append(float(3))
            elif str_list[0]=='grass':
                d.append(float(4))
            elif str_list[0]=='orchard':
                d.append(float(5)) 
            Crowdsource.append(d)
        Crowdsource = np.array(Crowdsource)
        data = Crowdsource[:,:-1]
        label =  Crowdsource[:,-1]
        scaler = preprocessing.MinMaxScaler()
        data = scaler.fit_transform(data)
        permutation = np.random.permutation(label.shape[0])
        data = data[permutation,:]
        label = label[permutation]
        data = torch.from_numpy(data)
        label = torch.from_numpy(label)
        data_split = int(len(data)*0.7)
        if train == True:
            data = data[:data_split]
            label = label[:data_split]
        else:
            data = data[data_split:]
            label = label[data_split:]
        
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data,label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data) 
            
cur_dir = os.getcwd()
train_dir = cur_dir+'/data/CrowdsourcedMapping/training.csv'
test_dir = cur_dir+'/data/CrowdsourcedMapping/testing.csv'
train_dataset =  Crowdsource(train_dir,'train')
test_dataset =  Crowdsource(train_dir,'test')

 
epochs = 50
h_dim = 100
batch_size = 50
learning_rate = 1e-3
input_dim = 28
output_dim = 6
layer_num =2

param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }