"""
Covtype dataset class and model parameters

"""

from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torchvision import transforms
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split


def get_data(data_dir):
    df = pd.read_csv(data_dir,header=None, sep=',', quotechar='"', error_bad_lines=False)
    df.columns=['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology',
           'Vertical_Distance_To_Hydrology', 'Horizontal_Distance_To_Roadways',
           'Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm',
           'Horizontal_Distance_To_Fire_Points', 'Wilderness_Area1',
           'Wilderness_Area2', 'Wilderness_Area3', 'Wilderness_Area4',
           'Soil_Type1', 'Soil_Type2', 'Soil_Type3', 'Soil_Type4', 'Soil_Type5',
           'Soil_Type6', 'Soil_Type7', 'Soil_Type8', 'Soil_Type9', 'Soil_Type10',
           'Soil_Type11', 'Soil_Type12', 'Soil_Type13', 'Soil_Type14',
           'Soil_Type15', 'Soil_Type16', 'Soil_Type17', 'Soil_Type18',
           'Soil_Type19', 'Soil_Type20', 'Soil_Type21', 'Soil_Type22',
           'Soil_Type23', 'Soil_Type24', 'Soil_Type25', 'Soil_Type26',
           'Soil_Type27', 'Soil_Type28', 'Soil_Type29', 'Soil_Type30',
           'Soil_Type31', 'Soil_Type32', 'Soil_Type33', 'Soil_Type34',
           'Soil_Type35', 'Soil_Type36', 'Soil_Type37', 'Soil_Type38',
           'Soil_Type39', 'Soil_Type40', 'Cover_Type']

    lbl=LabelEncoder()
    scaler=MinMaxScaler()

    y=df.Cover_Type.values
    y=lbl.fit_transform(y)
    X=df.drop(columns=['Cover_Type']).values
    X=scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.2, random_state=40)
    return X_train, X_test, y_train, y_test


class Covtype(data.Dataset):
    def __init__(self,X_train, X_test, y_train, y_test,train = True):
        self.train_x = X_train
        self.train_y = y_train
        self.test_x = X_test
        self.test_y = y_test
        self.train = train
        self.data,self.label = self.get_array(self.train_x,self.train_y,self.test_x,self.test_y,self.train)
        
    def get_array(self,train_x,train_y,test_x,test_y,train ):
        if train == True:
            data = train_x
            label = train_y
        else:
            data = test_x
            label = test_y
        data = torch.from_numpy(data)
        label = torch.from_numpy(label)
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data, label

    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
        return len(self.data)  
          
        
                
            
cur_dir = os.getcwd()
data_dir = cur_dir+'/data/covtypeData/covtype.data'
X_train, X_test, y_train, y_test = get_data(data_dir)
train_dataset = Covtype(X_train, X_test, y_train, y_test,'train')
test_dataset =  Covtype(X_train, X_test, y_train, y_test,'test')
 


epochs = 50
h_dim = 100
batch_size = 100
learning_rate = 1e-3
input_dim = 54
output_dim = 7
layer_num = 2



param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }

        