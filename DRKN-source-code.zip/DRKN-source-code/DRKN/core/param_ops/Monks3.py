"""
Monks3 dataset class and model parameters

"""
from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torch.utils import data

from torch.utils import data
class Monks(data.Dataset):
    def __init__(self,root):
        self.dir = root
        self.data,self.label = self.get_array(self.dir)
                  
    def get_array(self,root):
        f = open(root)
        data_list = []
        monks = [] 
        for line in f:
            s = line.strip().split('\t')
            data_list.append(s)
        f.close()
        
        for i in range(len(data_list)):
            d = []
            str_list = data_list[i][0].split(' ')
            str_list = str_list[:-1]
            for i in str_list:
                if i!= '':
                    d.append(float(i))
            monks.append(d)
        data = np.array(monks)
        data = data[:,1:]
        label = data[:,0]
        permutation = np.random.permutation(label.shape[0])
        data = data[permutation,:]
        label = label[permutation]
        data = torch.from_numpy(data) 
        label = torch.from_numpy(label)
        label-=1
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data,label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data) 
            
cur_dir = os.getcwd()            

train_dir = cur_dir+'/data/monksData/monks-3.train'
test_dir = cur_dir+'/data/monksData/monks-3.test'

train_dataset = Monks(train_dir)
test_dataset = Monks(test_dir)


epochs = 200
h_dim = 100
batch_size = 30
learning_rate = 1e-2
input_dim = 6
output_dim = 3
layer_num = 1

param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }