"""
Avila dataset class and model parameters

"""

from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing

class Avila(data.Dataset):
    def __init__(self,root,data_type):
        self.dir = root
        self.data,self.label = self.get_array(self.dir,data_type)
    
    def get_array(self,root,data_type): 
        f = open(root)
        data_list = []
        Avila = []
        for line in f:
            s = line.strip().split(',')
            data_list.append(s)
        f.close()
        for i in range(len(data_list)):
            d=[]
            str_list = data_list[i]
            for i in range(len(str_list)-1):
                d.append(float(str_list[i]))
            if str_list[-1] == 'A':
                d.append(float(0))
            elif str_list[-1] == 'B':
                d.append(float(1))
            elif str_list[-1] == 'C':
                d.append(float(2))
            elif str_list[-1] == 'D':
                d.append(float(3))
            elif str_list[-1] == 'E':
                d.append(float(4))
            elif str_list[-1] == 'F':
                d.append(float(5))
            elif str_list[-1] == 'G':
                d.append(float(6))
            elif str_list[-1] == 'H':
                d.append(float(7))
            elif str_list[-1] == 'I':
                d.append(float(8))
            elif str_list[-1] == 'W':
                d.append(float(9))
            elif str_list[-1] == 'X':
                d.append(float(10))
            elif str_list[-1] == 'Y':
                d.append(float(11))
            Avila.append(d)
        Avila = np.array(Avila)
        Avila = np.random.permutation(Avila)
        data =  Avila[:,:-1]
        label =  Avila[:,-1]
        scaler = preprocessing.MinMaxScaler()
        scaler = preprocessing.Normalizer()
        data = scaler.fit_transform(data)
        data = torch.from_numpy(data) 
        label = torch.from_numpy(label)
        data = data.type(torch.float32)
        label = label.type(torch.long)
        split_num = int(len(data)*0.75)
        if data_type == 'train':
            data = data[:split_num]
            label = label[:split_num]
        else:
            data = data[split_num:]
            label = label[split_num:]
        return data,label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data)   
        
cur_dir = os.getcwd()
data_dir = cur_dir+'/data/avila/avila-tr.txt'
train_dataset = Avila(data_dir,'train')
test_dataset = Avila(data_dir,'test')
epochs = 200
h_dim = 100
batch_size = 100
learning_rate = 1e-3
input_dim = 10
output_dim = 12
layer_num = 2

param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }