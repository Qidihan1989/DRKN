"""
EEG dataset class and model parameters

"""
from torch.utils import data
import os
import numpy as np
import torch
import torch.nn as nn
from sklearn import preprocessing
from torch.utils import data
from torchvision import transforms

class EEG(data.Dataset):
    def __init__(self,root,train = True,):
        self.dir = root
        self.train = train
        self.transforms = transforms
        self.data,self.label = self.get_array(self.dir,self.train,)
        
    def normalization(self,data):
        _range = torch.max(data,0)[0] - torch.min(data,0)[0]
        res = (data - torch.min(data,0)[0])/_range
        return res
        
    def standardization(self,data):
        mu = torch.mean(data,0)
        sigma = torch.std(data,0)
        res = (data-mu)/sigma
        return res
    
    def get_array(self,root,train): 
        f = open(root)
        data_list = []
        EEG = [] 
        for line in f:
            s = line.strip().split(',')
            data_list.append(s)
        f.close()
        for i in range(len(data_list)):
            d=[]
            str_list = data_list[i]
            for i in str_list:
                d.append(float(i))
            EEG.append(d)   
        
        EEG = preprocessing.scale(np.array(EEG))
        EEG = torch.from_numpy(EEG) 
        EEG = self.normalization(EEG)
        data_split = int(len(EEG)*0.7)
        if train == True:
            data = EEG[:data_split,:-1]
            label = EEG[:data_split,-1]
        else:
            data = EEG[data_split:,:-1]
            label = EEG[data_split:,-1]
        data = data.type(torch.float32)
        label = label.type(torch.long)
        return data,label
    
    def __getitem__(self,index):
        return self.data[index],self.label[index]
    
    def __len__(self,):
            return len(self.data) 
            
            
                  
cur_dir = os.getcwd()
eeg_dir = cur_dir+'/data/EEGData/EEG Eye State.arff'
# 超参数设置
epochs = 50
h_dim = 100
batch_size = 50
learning_rate = 1e-3
input_dim = 14
output_dim = 2
layer_num = 1

train_dataset = EEG(eeg_dir,'train',)
test_dataset = EEG(eeg_dir,'test',)


param = {'train_dataset':train_dataset,
             'test_dataset':test_dataset,
             'ops':{'epochs':epochs,
                    'h_dim':h_dim,
                    'batch_size':batch_size,
                    'learning_rate':learning_rate,
                    'input_dim':input_dim,
                    'output_dim':output_dim,
                    'layer_num':layer_num
                   }
            }