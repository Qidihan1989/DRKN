"""
methods of training and testing for DRKN and DNN
"""
import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math
import core.param_ops
from core import DRKN_model
from core import train_test

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
criterion = nn.CrossEntropyLoss() 

def progress_bar(current,total,msg=None):
    progress = current / total
    bar_length = 20
    filled_length = int(round(bar_length*progress))
    bar = '='*filled_length + '-'*(bar_length - filled_length)
    if msg:
        print(f'\r[{bar}]{progress*100:.1f}%{msg}',end='')
    else:
        print(f'\r[{bar}]{progress*100:.1f}%',end='')
    if current == total-1:
        print()

def train_DRKN(epoch,model,optimizer,train_loader,dataset,):
    print('\nEpoch:%d'%epoch)
    print('training')
    train_loss = 0
    correct = 0
    total = 0
    for batch_idx,(inputs,targets) in enumerate(train_loader):
        inputs, targets= inputs.to(device), targets.to(device)
        if dataset == 'MNIST':
                inputs =  inputs.view(-1, 784)
        y_pred,kl_loss= model(inputs)
        loss = criterion(y_pred,targets) 
        total_loss = 1.0*kl_loss + loss
        if total_loss.item() < 0.01:
               break
        optimizer.zero_grad()
        total_loss.backward()
        optimizer.step()
        train_loss += loss.item()
        _, predicted_1 = torch.max(y_pred.data, 1)
        total += targets.size(0)
        correct += (predicted_1 == targets).sum().item()
        progress_bar(batch_idx,len(train_loader),'Loss:%.3f | ACC:%.3f%%'%(train_loss/(batch_idx+1),100.*correct/total))
        
def train_DNN(epoch,model,optimizer,train_loader,dataset,):
    print('\nEpoch:%d'%epoch)
    print('training')
    train_loss = 0
    correct = 0
    total = 0
 
    for batch_idx,(inputs,targets) in enumerate(train_loader):
        inputs, targets= inputs.to(device), targets.to(device)
        if dataset == 'MNIST':
                inputs =  inputs.view(-1, 784)
        y_pred= model(inputs)
        loss = criterion(y_pred,targets) 
        total_loss = loss
        if total_loss.item() < 0.03:
               break
        optimizer.zero_grad()
        total_loss.backward()
        optimizer.step()
        train_loss += loss.item()
        _, predicted_1 = torch.max(y_pred.data, 1)
        total += targets.size(0)
        correct += (predicted_1 == targets).sum().item()
        progress_bar(batch_idx,len(train_loader),'Loss:%.3f | ACC:%.3f%%'%(train_loss/(batch_idx+1),100.*correct/total))

def test_DRKN(model,test_loader,dataset):
    print('testing')
    global best_acc
    global best_model
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx,(inputs,targets) in enumerate(test_loader):
            inputs, targets= inputs.to(device), targets.to(device)
            if dataset == 'MNIST':
                inputs =  inputs.view(-1, 784)
            y_pred,kl_loss= model(inputs)
            loss = criterion(y_pred,targets) 
            total_loss = 1.0*kl_loss + loss
            if total_loss.item() < 0.01:
               break
            test_loss += loss.item()
            _, predicted_1 = torch.max(y_pred.data, 1)
            total += targets.size(0)
            correct += (predicted_1 == targets).sum().item()
            progress_bar(batch_idx,len(test_loader),'Loss:%.3f | ACC:%.3f%%'%(test_loss/(batch_idx+1),100.*correct/total))
            
#   acc = 100*correct/total
#   if acc > best_acc:
#        print('Saving..best_acc:%.3f'%acc)
#        best_acc = acc
#        best_model = model

def test_DNN(model,test_loader,dataset):
    print('testing')
    global best_acc
    global best_model
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx,(inputs,targets) in enumerate(test_loader):
            inputs, targets= inputs.to(device), targets.to(device)
            if dataset == 'MNIST':
                inputs =  inputs.view(-1, 784)
            y_pred = model(inputs)
            loss = criterion(y_pred,targets) 
            total_loss =  loss
            if total_loss.item() < 0.03:
               break
            test_loss += loss.item()
            _, predicted_1 = torch.max(y_pred.data, 1)
            total += targets.size(0)
            correct += (predicted_1 == targets).sum().item()
            progress_bar(batch_idx,len(test_loader),'Loss:%.3f | ACC:%.3f%%'%(test_loss/(batch_idx+1),100.*correct/total))
            
#   acc = 100*correct/total
#   if acc > best_acc:
#        print('Saving..best_acc:%.3f'%acc)
#        best_acc = acc
#        best_model = model


def model_loader_optimizer_fc(param):
    DRKN_fc_G = DRKN_model.RFF_net(param['ops']['batch_size'],
                         param['ops']['input_dim'],
                         param['ops']['output_dim'],
                         param['ops']['h_dim'],
                         param['ops']['layer_num'],
                         "Gaussian")
    DRKN_fc_A = DRKN_model.RFF_net(param['ops']['batch_size'],
                         param['ops']['input_dim'],
                         param['ops']['output_dim'],
                         param['ops']['h_dim'],
                         param['ops']['layer_num'],
                         "Arc")
    train_loader = torch.utils.data.DataLoader(dataset = param['train_dataset'], 
                                               batch_size = param['ops']['batch_size'], 
                                               shuffle = True,drop_last=True)  

    test_loader = torch.utils.data.DataLoader(dataset = param['test_dataset'],
                                              batch_size = param['ops']['batch_size'],
                                              shuffle = True,drop_last=True)
    DRKN_fc_G_optimizer = torch.optim.Adam(DRKN_fc_G.parameters(),lr=param['ops']['learning_rate'])
    DRKN_fc_A_optimizer = torch.optim.Adam(DRKN_fc_A.parameters(),lr=param['ops']['learning_rate'])
    return DRKN_fc_G,DRKN_fc_A,train_loader,test_loader,DRKN_fc_G_optimizer,DRKN_fc_A_optimizer

def model_loader_optimizer_conv(param):
    DRKN_conv_G = DRKN_model.RFF_Cov_net(param['ops']['batch_size'],
                         param['ops']['input_dim'],
                         param['ops']['output_dim'],
                         param['ops']['h_dim'],     
                         param['ops']['conv_param_1'],
                         param['ops']['conv_param_2'],
                         param['ops']['layer_num'],
                         "Gaussian")
    DRKN_conv_A = DRKN_model.RFF_Cov_net(param['ops']['batch_size'],
                         param['ops']['input_dim'],
                         param['ops']['output_dim'],
                         param['ops']['h_dim'],
                         param['ops']['conv_param_1'],
                         param['ops']['conv_param_2'],
                         param['ops']['layer_num'],
                         "Arc")
    train_loader = torch.utils.data.DataLoader(dataset = param['train_dataset'], 
                                               batch_size = param['ops']['batch_size'], 
                                               shuffle = True,drop_last=True)  

    test_loader = torch.utils.data.DataLoader(dataset = param['test_dataset'],
                                              batch_size = param['ops']['batch_size'],
                                              shuffle = True,drop_last=True)
    DRKN_conv_G_optimizer = torch.optim.Adam(DRKN_conv_G.parameters(),lr=param['ops']['learning_rate'])
    DRKN_conv_A_optimizer = torch.optim.Adam(DRKN_conv_A.parameters(),lr=param['ops']['learning_rate'])
    return DRKN_conv_G,DRKN_conv_A,train_loader,test_loader,DRKN_conv_G_optimizer,DRKN_conv_A_optimizer
        