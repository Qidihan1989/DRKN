"""
the performance of DRKN-fc on MNIST dataset
model:DRKN-fc-G,DRKN-fc-A,DNN-relu,DNN-cos
We also investigate the characteristics of DRKN-fc and DNN in optimization.
The input Gram matrix and learned Gram matrices by the trained models are saved in file experiment_result

"""
import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math
import core
import seaborn as sns
from sklearn import preprocessing
import core.param_ops
from core import DRKN_model
from core import train_test

"""
config
"""
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
cur_dir = os.getcwd()
MNIST_data_dir = cur_dir+'/data/MNIST/'
EPOCH = 200
h_dim = 100
batch_size = 50
learning_rate = 1e-3
input_dim = 784
out_dim = 10
train_dataset = torchvision.datasets.MNIST(root = MNIST_data_dir, 
                           train = True, 
                           transform = transforms.ToTensor(), 
                           download = True) 
test_dataset = torchvision.datasets.MNIST(root = MNIST_data_dir, 
                           train = False, 
                           transform = transforms.ToTensor(), 
                           download = True) 
train_loader = torch.utils.data.DataLoader(dataset = train_dataset, 
                                           batch_size = batch_size, 
                                           shuffle = True,drop_last=True)  
test_loader = torch.utils.data.DataLoader(dataset = test_dataset,
                                          batch_size = batch_size,
                                          shuffle = True,drop_last=True) 
USE_CUDA = torch.cuda.is_available() 

#function: Visualization of image data
def matplotlib_imshow(img, one_channel=False):
    if one_channel:
        img = img.mean(dim=0)
    img = img / 2 + 0.5     # unnormalize
    npimg = img.numpy()
    if one_channel:
        plt.imshow(npimg, cmap='grey')
    else:
        plt.imshow(np.transpose(npimg, (1, 2, 0)))
        
# function: select 50 MNIST data points with the same label.   
def make_label_data(label):
    input_label = label
    data = []
    for i in range(len(train_dataset)):
        i+=100
        data_label = train_dataset[i][1]
        if data_label==input_label:
            data.append(train_dataset[i][0].numpy())
        if len(data)==50:
            break
    return torch.tensor(np.array(data))
    
#DNN-cos class for MNIST experiment   
class cos_Net(nn.Module):
    def __init__(self):
        super(cos_Net,self).__init__()
        self.l0 = nn.Linear(784,50)
        self.l1 = nn.Linear(50,50)
        self.l2 = nn.Linear(50,50)
        self.l3 = nn.Linear(50,50)
        self.l4 = nn.Linear(50,10)
        
    def forward(self,x):
        x1 = torch.cos(self.l0(x))
        self.layer_Gram_matrix_1 = torch.matmul(x1,x1.t())
        x2 = torch.cos(self.l1(x1))
        self.layer_Gram_matrix_2 = torch.matmul(x2,x2.t())
        x3 = torch.cos(self.l2(x2))
        self.layer_Gram_matrix_3 = torch.matmul(x3,x3.t())
        x4 = torch.cos(self.l3(x3))
        self.layer_Gram_matrix_4 = torch.matmul(x4,x4.t())
        x5 = self.l4(x4)
        return x5
        
#DNN-relu class for MNIST experiment          
class relu_Net(nn.Module):
    def __init__(self):
        super(relu_Net,self).__init__()
        self.l0 = nn.Linear(784,50)
        self.l1 = nn.Linear(50,50)
        self.l2 = nn.Linear(50,50)
        self.l3 = nn.Linear(50,50)
        self.l4 = nn.Linear(50,10)
        
    def forward(self,x):
        x1 = F.relu(self.l0(x))
        self.layer_Gram_matrix_1 = torch.matmul(x1,x1.t())
        x2 = F.relu(self.l1(x1))
        self.layer_Gram_matrix_2 = torch.matmul(x2,x2.t())
        x3 = F.relu(self.l2(x2))
        self.layer_Gram_matrix_3 = torch.matmul(x3,x3.t())
        x4 = F.relu(self.l3(x3))
        self.layer_Gram_matrix_4 = torch.matmul(x4,x4.t())
        x5 = self.l4(x4)
        return x5
        
def main():
#create experiment results file
	cur_dir = os.getcwd()
	results_dir = os.path.join(cur_dir,'experiment_result')
	if not os.path.exists(results_dir):
    		os.makedirs(results_dir)
		
	print('+++++++++++++++++++++++++++++Performance comparison on MNIST dataset+++++++++++++++++++++++++++++++')

	A_net = DRKN_model.RFF_net(batch_size,input_dim,out_dim,h_dim,4,'ARC')
	A_optimizer = torch.optim.Adam(A_net.parameters(),lr=learning_rate) 

	G_net = DRKN_model.RFF_net(batch_size,input_dim,out_dim,h_dim,4,'Gaussian')
	G_optimizer = torch.optim.Adam(G_net.parameters(),lr=learning_rate) 
	
	relu_net = relu_Net()
	relu_optimizer = torch.optim.Adam(relu_net.parameters(),lr=learning_rate)
	 
	cos_net = cos_Net()
	cos_optimizer = torch.optim.Adam(cos_net.parameters(),lr=learning_rate)
	
	print('======================================================================')
	print('+++++++++++++++Experiment on MNIST for DRKN-fc-A model++++++++++++++++++++++')
	print('======================================================================')
	for e in range(EPOCH):
		train_test.train_DRKN(e,A_net,A_optimizer,train_loader,'MNIST')
		print('\n')
		train_test.test_DRKN(A_net,test_loader,'MNIST')
	print('\n')
	print('======================================================================')
	print('+++++++++++++++Experiment on MNIST for DRKN-fc-G model+++++++++++++++++++++')
	print('======================================================================')
	for e in range(EPOCH):
		train_test.train_DRKN(e,G_net,G_optimizer,train_loader,'MNIST' )
		print('\n')
		train_test.test_DRKN(G_net,test_loader,'MNIST')
		
	print('\n')
	print('======================================================================')
	print('+++++++++++++++Experiment on MNIST for DNN-relu model+++++++++++++++++++++++')
	print('======================================================================')
	for e in range(EPOCH):
		train_test.train_DNN(e,relu_net,relu_optimizer,train_loader,'MNIST')
		print('\n')
		train_test.test_DNN(relu_net,test_loader,'MNIST')
	
	print('\n')
	print('======================================================================')
	print('+++++++++++++++++Experiment on MNIST for DNN-cos model+++++++++++++++++++++')
	print('======================================================================')
	for e in range(EPOCH):
		train_test.train_DNN(e,cos_net,cos_optimizer,train_loader,'MNIST' )
		print('\n')
		train_test.test_DNN(cos_net,test_loader,'MNIST')
	
	print('\n')
	print('======================================================================')
	print('++++++++++++++++++++++Selecting 50 data points with the same label++++++++++++++++')
	print('======================================================================')
	
#create the datasets with the same label
	label_0 = make_label_data(0)
	label_1 = make_label_data(1)
	label_2 = make_label_data(2)
	label_3 = make_label_data(3)
	label_4 = make_label_data(4)
	label_5 = make_label_data(5)
	label_6 = make_label_data(6)
	label_7 = make_label_data(7)
	label_8 = make_label_data(8)
	label_9 = make_label_data(9)  
	
#dataset: select the datasets with the same label (label==5).   
	data = label_5
	images = data.reshape(-1,28*28)
	
# the Gram matrix of the input data 
	imput_Gram = torch.matmul(images,images.t()).detach().numpy()
	scaler = preprocessing.MinMaxScaler()
	imput_Gram = scaler.fit_transform(imput_Gram)
	
	
	A_res = A_net(images)
	G_res = G_net(images)
	cos_res = cos_net(images)
	relu_res = relu_net(images)
	
# the Gram matrices learned by the trained DRKN-fc-G at each layer.
	G_Gram_1 = G_net.rff_1.layer_Gram_matrix.detach().numpy()
	G_Gram_2 = G_net.rff_net.rff_2.layer_Gram_matrix.detach().numpy()
	G_Gram_3 = G_net.rff_net.rff_3.layer_Gram_matrix.detach().numpy()
	G_Gram_4 = G_net.rff_net.rff_4.layer_Gram_matrix.detach().numpy()
	scaler = preprocessing.MinMaxScaler()
	G_Gram_1 = scaler.fit_transform(G_Gram_1)
	G_Gram_2 = scaler.fit_transform(G_Gram_2) 
	G_Gram_3 = scaler.fit_transform(G_Gram_3) 
	G_Gram_4 = scaler.fit_transform(G_Gram_4) 

# the Gram matrices learned by the trained DRKN-fc-A at each layer.
	A_Gram_1 = A_net.rff_1.layer_Gram_matrix.detach().numpy()
	A_Gram_2 = A_net.rff_net.rff_2.layer_Gram_matrix.detach().numpy()
	A_Gram_3 = A_net.rff_net.rff_3.layer_Gram_matrix.detach().numpy()
	A_Gram_4 = A_net.rff_net.rff_4.layer_Gram_matrix.detach().numpy()
	scaler = preprocessing.MinMaxScaler()
	A_Gram_1 = scaler.fit_transform(A_Gram_1)
	A_Gram_2 = scaler.fit_transform(A_Gram_2) 
	A_Gram_3 = scaler.fit_transform(A_Gram_3) 
	A_Gram_4 = scaler.fit_transform(A_Gram_4) 
	
# the Gram matrices learned by the trained DNN-cos at each layer.	
	cos_net_Gram_1 = cos_net.layer_Gram_matrix_1.detach().numpy()
	cos_net_Gram_2 = cos_net.layer_Gram_matrix_2.detach().numpy()
	cos_net_Gram_3 = cos_net.layer_Gram_matrix_3.detach().numpy()
	cos_net_Gram_4 = cos_net.layer_Gram_matrix_4.detach().numpy()
	scaler = preprocessing.MinMaxScaler()
	cos_net_Gram_1 = scaler.fit_transform(cos_net_Gram_1)
	cos_net_Gram_2 = scaler.fit_transform(cos_net_Gram_2)
	cos_net_Gram_3 = scaler.fit_transform(cos_net_Gram_3)
	cos_net_Gram_4 = scaler.fit_transform(cos_net_Gram_4)
	
# the Gram matrices learned by the trained DNN-relu at each layer.	
	relu_net_Gram_1 = relu_net.layer_Gram_matrix_1.detach().numpy()
	relu_net_Gram_2 = relu_net.layer_Gram_matrix_2.detach().numpy()
	relu_net_Gram_3 = relu_net.layer_Gram_matrix_3.detach().numpy()
	relu_net_Gram_4 = relu_net.layer_Gram_matrix_4.detach().numpy()
	scaler = preprocessing.MinMaxScaler()
	relu_net_Gram_1 = scaler.fit_transform(relu_net_Gram_1)
	relu_net_Gram_2 = scaler.fit_transform(relu_net_Gram_2)
	relu_net_Gram_3 = scaler.fit_transform(relu_net_Gram_3)
	relu_net_Gram_4 = scaler.fit_transform(relu_net_Gram_4)

	print('\n')
	print('=============================================================================')
	print('Visualization of the input data and  Gram matrix. See Fig. Input data and Gram matrix.jpg')
	print('=============================================================================')
	
#Visualization of input data 
	fig=plt.figure(figsize=(15,5))
	plt.subplot(1,2,1)
	matplotlib_imshow(data[0])
	
	
#Visualization of the input data and  Gram matrix	
	plt.subplot(1,2,2)
	sns.heatmap(data=imput_Gram,
           cmap='Blues',
           cbar=True,      
    	)
	input_data_Gram = results_dir+'/Input data and Gram matrix.jpg'
	plt.savefig(input_data_Gram)
	

	print('\n')
	print('=============================================================================')
	print('Visualization of the Gram matrices learned by the trained models at each layer. See Fig. Gram-Matrices of trained models.jpg')
	print('=============================================================================')
	
	fig=plt.figure(figsize=(40,25))
	plt.subplot(4,4,1)
	sns.heatmap(data=A_Gram_1,
                  cmap='Blues',
#                cbar=True, 
    #            linewidths=.005
             )
	plt.subplot(4,4,2)
	sns.heatmap(data=A_Gram_2,        
                  cmap='Blues', 
#                cbar=True,
    #            linewidths=.005
             )
	plt.subplot(4,4,3)
	sns.heatmap(data=A_Gram_3,
                  cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )
	plt.subplot(4,4,4)
	sns.heatmap(data=A_Gram_4,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )


	plt.subplot(4,4,5)
	sns.heatmap(data=G_Gram_3,
               cmap='Blues',
#                cbar=True, 
    #            linewidths=.005
             )
	plt.subplot(4,4,6)
	sns.heatmap(data=G_Gram_3,        
               cmap='Blues', 
#                cbar=True,
    #            linewidths=.005
             )
	plt.subplot(4,4,7)
	sns.heatmap(data=G_Gram_3,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )
	plt.subplot(4,4,8)
	sns.heatmap(data=G_Gram_3,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )

	plt.subplot(4,4,9)
	sns.heatmap(data=cos_net_Gram_1,
               cmap='Blues',
#                cbar=True, 
    #            linewidths=.005
             )
	plt.subplot(4,4,10)
	sns.heatmap(data=cos_net_Gram_2,        
               cmap='Blues', 
#                cbar=True,
    #            linewidths=.005
             )
	plt.subplot(4,4,11)
	sns.heatmap(data=cos_net_Gram_3,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )
	plt.subplot(4,4,12)
	sns.heatmap(data=cos_net_Gram_4,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )


	plt.subplot(4,4,13)
	sns.heatmap(data=relu_net_Gram_1,
               cmap='Blues',
#                cbar=True, 
    #            linewidths=.005
             )
	plt.subplot(4,4,14)
	sns.heatmap(data=relu_net_Gram_2,        
               cmap='Blues', 
#                cbar=True,
    #            linewidths=.005
             )
	plt.subplot(4,4,15)
	sns.heatmap(data=relu_net_Gram_3,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )
	plt.subplot(4,4,16)
	sns.heatmap(data=relu_net_Gram_4,
               cmap='Blues',
#                 cbar=True, 
    #             linewidths=.05,
            )
	plt.axis('off')
	plt.xlabel('number of features',fontsize = 15,fontproperties = 'Times New Roman')
	plt.ylabel('number of features',fontsize = 15,fontproperties = 'Times New Roman')
	trained_Gram = results_dir+'/Gram-Matrices of trained models.jpg'
	plt.savefig(trained_Gram)
	
if __name__ == '__main__':
    main()
