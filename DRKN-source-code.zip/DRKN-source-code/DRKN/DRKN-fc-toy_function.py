"""
regression tasks with toy functions
Model:DRKN-fc-G
architecture: 1-50-50-1
the target functions and learned functions are saved in the file experiment_result
"""

import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math
import core
import seaborn as sns
from sklearn import preprocessing
import core.param_ops
from core import DRKN_model
from core import train_test
from torch.utils import data
from mpl_toolkits import mplot3d


#define target fucntion
def f1(x, y):
    return np.sin(np.sqrt((x**2)+(y**2)))/((x**2)+(y**2)+1)

def f2(x,y):
    return np.exp(-8*(3-np.sqrt((x**2)+(y**2)))**2)-np.exp(-8*(1.5-np.sqrt((x**2)+(y**2)))**2)-np.exp(-8*(2-np.sqrt((x**2)+(y**2)))**2)

#DRKN-fc class for toy_function experiment   
class RFF_net(nn.Module):
    def __init__(self,data_batch,out_dim,approximation):
        super(RFF_net,self).__init__()
        self.data_batch = data_batch
        self.out_dim = out_dim
        self.approximation = approximation
        self.rff_net_initial()
        
    def rff_net_initial(self,):
        self.layer_construction()
        nn.init.kaiming_normal_(self.output_layer.weight.data)
              
    def layer_construction(self,):
        self.rff_1 = DRKN_model.rff_layer(self.data_batch,2,50,50,self.approximation)
        self.rff_2 = DRKN_model.rff_layer(self.data_batch,50,50,50,self.approximation)
        self.output_layer = nn.Linear(self.data_batch, self.out_dim)
        
               
    def forward(self,x):
        res_, layer_1_loss= self.rff_1(x)
        res_, layer_2_loss= self.rff_2(res_)
        res_ = self.output_layer(res_)
        sum_layer_loss = layer_1_loss +layer_2_loss
        loss = sum_layer_loss/2
        return res_,loss

    def pred(self,x):
        res_ = self.rff_1.pred(x)
        res_ = self.rff_2.pred(res_)
        pred_y = self.output_layer(res_)
        return pred_y
    
#toy function dataset       
class toy_model_data(data.Dataset):
    def __init__(self,data,label):
        self.train_data = data
        self.train_label = label
    
    def __getitem__(self,index):
        data = self.train_data[index]
        label = self.train_label[index] 
        data = torch.from_numpy(data) 
        label = torch.from_numpy(label) 
        data = data.type(torch.float32)
        label = label.type(torch.float32)
        return data,label
    
    def __len__(self,):
        return len(self.train_data) 
     
def main():
#create experiment results file
    cur_dir = os.getcwd()
    results_dir = os.path.join(cur_dir,'experiment_result')
    if not os.path.exists(results_dir):
    	os.makedirs(results_dir)
 
    print('+++++++++++++++++++++++++++++Experiment on Toy  Functions+++++++++++++++++++++++++++++++')
#training data
    train_x = 3*np.random.randn(10000,2)
    train_f1_label = f1(train_x[:,0],train_x[:,1])
    train_f1_label = train_f1_label.reshape(-1,1)
    train_f2_label = f2(train_x[:,0],train_x[:,1])
    train_f2_label = train_f2_label.reshape(-1,1)
    toy_train_f1_data= toy_model_data(train_x,train_f1_label)
    toy_train_f2_data= toy_model_data(train_x,train_f2_label)	
    
    print('======================================================================')
    print('+++++++++++++++Visualization of the target function 1, see Fig. target function 1 ++++++++++++++++++++++')
    print('======================================================================')
    
#show target function 1 
    ax1 = plt.axes(projection='3d')
    ax2 = plt.axes(projection='3d')
    train_x  = np.linspace(-3.3,3.3,100)
    x,y = np.meshgrid(train_x,train_x)
    
    z1 = f1(x,y)
    ax2.plot_surface(x, y, z1,cmap='coolwarm',edgecolor='none',alpha=1, rstride =1 ,cstride =1)
    target_function1 = results_dir+'/target function1.jpg'
    plt.savefig(target_function1)
    
    print('======================================================================')
    print('+++++++++++++++Visualization of the target function 2, see Fig. target function 2 ++++++++++++++++++++++')
    print('======================================================================')
    
#show target function 2    
    z2 = f2(x,y)
    ax2.plot_surface(x, y, z2,cmap='coolwarm',edgecolor='none',alpha=1, rstride =1 ,cstride =1)
    target_function2= results_dir+'/target function2.jpg'
    plt.savefig(target_function2)
    
# parameters setting and dataloader initialization
    EPOCH = 10
    pre_epoch = 0
    batch_size = 50
    toy1_train_loader = torch.utils.data.DataLoader(dataset = toy_train_f1_data, batch_size = batch_size, shuffle = True,drop_last=True)
    toy2_train_loader = torch.utils.data.DataLoader(dataset = toy_train_f2_data, batch_size = batch_size, shuffle = True,drop_last=True)
    criterion = nn.MSELoss()
    G1_net = RFF_net(50,1,'Gaussian')
    G2_net= RFF_net(50,1,'Gaussian')
    G1_optimizer = torch.optim.Adam(G1_net.parameters(),lr=1e-4) 
    G2_optimizer = torch.optim.Adam(G2_net.parameters(),lr=1e-4)
    
    print('======================================================================')
    print('+++++++++++++++++++++++++++++++Train DRKN-fc-G model on target function 1 +++++++++++++++++++++++++++++++++++')
    print('======================================================================')
    
#train the DRKN-fc-G on target function 1 dataset   
    for e in range(1000):
        for i,data in enumerate(toy1_train_loader):  
            (images,labels) = data
            y_pred,kl_loss = G1_net(images)
            loss =  criterion(y_pred,labels)
            total_loss = 1.0*kl_loss + loss
            if loss.item() < 0.0006:
                break
            print('loss:',loss)
            G1_optimizer.zero_grad()
            total_loss.backward() 
            G1_optimizer.step()
            
    print('======================================================================')
    print('+++++++++++++++++++Visualization of the learned function1, see Fig. learned function 1  +++++++++++++++')
    print('======================================================================')
    
#visualize the learned target function1
    x = np.linspace(-3.3,3.3,100)
    y = np.linspace(-3.3,3.3,100)
    x,y = np.meshgrid(x, y)
    x1=x.reshape(-1,1)
    y1=y.reshape(-1,1)
    train_x = np.hstack([x1,y1])
    draw_data = torch.from_numpy(train_x)
    draw_data= draw_data.type(torch.float32)

    G_z1 = G1_net.pred(draw_data)
    G_z1 = G_z1.reshape(100,-1)
    G_z1 = G_z1.detach().numpy()
    ax1 = plt.axes(projection='3d')
    ax1.plot_surface(x,y, G_z1,cmap='coolwarm',edgecolor='none',alpha=1, rstride =1 ,cstride =1,)
    learned_function1 = results_dir+'/learned function1.jpg'
    plt.savefig(learned_function1)
    
    
    print('======================================================================')
    print('+++++++++++++++++++++++++++++++Train DRKN-fc-G model on target function 2 +++++++++++++++++++++++++++++++++++')
    print('======================================================================')
    
    
#train the DRKN-fc-G on target function 2 dataset                 
    for e in range(1000):
        for i,data in enumerate(toy2_train_loader):  
            (images,labels) = data
            y_pred,kl_loss = G2_net(images)
            loss =  criterion(y_pred,labels)
            total_loss = 1.0*kl_loss + loss
            if loss.item() < 0.0006:
                break
            print('loss:',loss)
            G2_optimizer.zero_grad()
            total_loss.backward() 
            G2_optimizer.step()
    print('======================================================================')
    print('+++++++++++++++++++Visualization of the learned function2, see Fig. learned function 2 +++++++++++++++')
    print('======================================================================')
    
#visualize the learned target function 2
    G_z2 = G2_net.pred(draw_data)
    G_z2 = G_z2.reshape(100,-1)
    G_z2 = G_z2.detach().numpy()
    ax1 = plt.axes(projection='3d')
    ax1.plot_surface(x,y, G_z2,cmap='coolwarm',edgecolor='none',alpha=1, rstride =1 ,cstride =1,)
    learned_function2 = results_dir+'/learned function2.jpg'
    plt.savefig(learned_function2)
if __name__ == '__main__':
    main()
