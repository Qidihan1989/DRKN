"""
the performance of DRKN-fc on UCI dataset
Datasets:'Fertility','Monks1','Monks2','Monks3','Climate','QSAR','Phishing',Adult','Covtype'
Model:DRKN-fc-A,DRKN-fc-G
If you would like to test a single dataset, change the small_scale_datasets List and large_scale_datasets List
"""

import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math
import core
import core.param_ops
from core import DRKN_model
from core import train_test


def main():
#create experiment results file
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    criterion = nn.CrossEntropyLoss() 
    cur_dir = os.getcwd()
    results_dir = os.path.join(cur_dir,'experiment_result')
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    filepath = results_dir+"/UCI_test_acc.txt"
#    if not os.path.exists(filepath):
#       os.makedirs(filepath)

#UCI dataset list
    small_scale_datasets = ['Fertility','Monks1','Monks2','Monks3','Climate','QSAR']
    large_scale_datasets = ['Adult','Covtype']
    
    print('+++++++++++++++++++++++++++++Performance comparison on UCI datasets+++++++++++++++++++++++++++++++')

#get the parameter for each dataset
    for dataset in small_scale_datasets:
        if dataset == 'Avila':
            from core.param_ops import Avila
            param = Avila.param
        elif dataset == 'Fertility':
            from core.param_ops import Fertility
            param = core.param_ops.Fertility.param
        elif dataset == 'Monks1':
            from core.param_ops import Monks1
            param = core.param_ops.Monks1.param
        elif dataset == 'Monks2':
            from core.param_ops import Monks2
            param = core.param_ops.Monks2.param
        elif dataset == 'Monks3':
            from core.param_ops import Monks3
            param = core.param_ops.Monks3.param
        elif dataset == 'Climate':
            from core.param_ops import Climate
            param = core.param_ops.Climate.param
        elif dataset =='EEG':
            from core.param_ops import EEG
            param = core.param_ops.EEG.param
        elif dataset =='QSAR':
            from core.param_ops import QSAR
            param = core.param_ops.QSAR.param
        elif dataset == 'Phishing':
            from core.param_ops import Phishing
            param = core.param_ops.Phishing.param
        elif dataset == 'Website':
            from core.param_ops import Website
            param = core.param_ops.Website.param
        elif dataset == 'Crowd':
            from core.param_ops import Crowd
            param = core.param_ops.Crowd.param
        elif dataset == 'ShillBidding':
            from core.param_ops import ShillBidding
            param = core.param_ops.ShillBidding.param  
        elif dataset == 'Adult':
            from core.param_ops import Adult
            param = core.param_ops.Adult.param
        elif dataset == 'Covtype':
            from core.param_ops import Covtype
            param = core.param_ops.Covtype.param

#get the model for each dataset            
        epoches = param['ops']['epochs']
        G_net,A_net,train_loader,test_loader,G_optimizer,A_optimizer =train_test.model_loader_optimizer_fc(param)
        print('======================================================================')
        print('=========================dataset:{} ========================='.format(dataset))
        print('======================================================================')
        print('\n')
        print('======================================================================')
        print('=========================model:DRKN_fc_G==============================')
        print('======================================================================')
 
#training and testing
        for e in range(epoches):
                train_test.train_DRKN(e,G_net,G_optimizer,train_loader,dataset)
                print('\n')
                train_test.test_DRKN(G_net,test_loader,dataset)
#get the results
        test_loss = 0
        correct = 0
        total = 0
        with torch.no_grad():
            for batch_idx,(inputs,targets) in enumerate(test_loader):
                inputs, targets= inputs.to(device), targets.to(device)
                y_pred,kl_loss= G_net(inputs)
                loss = criterion(y_pred,targets) 
                total_loss = 1.0*kl_loss + loss
                test_loss += loss.item()
                _, predicted_1 = torch.max(y_pred.data, 1)
                total += targets.size(0)
                correct += (predicted_1 == targets).sum().item()
                res_ = 'dataset:{},model: DRKN-fc-G,test_acc:{}'.format(dataset,100.*correct/total)
        with open(filepath, 'a') as file:
            file.write(res_)
            file.write('\n')
            file.close()
        print('======================================================================')
        print('=========================model:DRKN_fc_A==============================')
        print('======================================================================')
    
#training and testing
        for e in range(epoches):
                train_test.train_DRKN(e,A_net,A_optimizer,train_loader,dataset)
                print('\n')
                train_test.test_DRKN(A_net,test_loader,dataset)
#get the results
        test_loss = 0
        correct = 0
        total = 0
        with torch.no_grad():
            for batch_idx,(inputs,targets) in enumerate(test_loader):
                inputs, targets= inputs.to(device), targets.to(device)
                y_pred,kl_loss= A_net(inputs)
                loss = criterion(y_pred,targets) 
                total_loss = 1.0*kl_loss + loss
                test_loss += loss.item()
                _, predicted_1 = torch.max(y_pred.data, 1)
                total += targets.size(0)
                correct += (predicted_1 == targets).sum().item()
                res_ = 'dataset:{},model: DRKN-fc-A,test_acc:{}'.format(dataset,100.*correct/total)
        with open(filepath, 'a') as file:
            file.write(res_)
            file.write('\n')
            file.close()
          
if __name__ == '__main__':
    main()
