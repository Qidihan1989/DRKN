"""
the performance of DRKN-conv on CIFAR10 dataset
Model:DRKN-conv-A
If you would like to run DRKN-conv-G model,use kernel_approximation='Gaussian' instead

"""
import numpy as np
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import torch
import torch.nn as nn
import os
from torchvision import transforms
from torchvision.utils import save_image
import torchvision
import matplotlib.pyplot as plt
from torch.utils import data
import math
import core
import core.param_ops
from core import DRKN_model
from core import train_test


"""
config
"""
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
transform_train = transforms.Compose([
    transforms.CenterCrop(32),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
])

transform_test = transforms.Compose([
    transforms.CenterCrop(32),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
])

cur_dir = os.getcwd()
CIFAR10_data_dir = cur_dir+'/data/CIFAR10/'

epochs = 1000
learning_rate = 1e-4
batch_size=100
input_feature = 32
out_dim = 10
h_dim = 256
layer_num = 4
kernel_approximation='ARC'

trainset =  torchvision.datasets.CIFAR10(root = CIFAR10_data_dir , train=True, download=True,transform=transform_train)
train_loader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True,drop_last=True, num_workers=2)

testset = torchvision.datasets.CIFAR10(root = CIFAR10_data_dir , train=False, download=True,transform=transform_test)
test_loader = torch.utils.data.DataLoader(testset, batch_size=batch_size, shuffle=True,drop_last=True,  num_workers=2)

conv_param_1 = {'F':64,'C':3,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_2 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_3 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_4 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_5 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_6 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_7 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_8 = {'F':64,'C':64,'H':5,'W':5,'stride':1,'pad':2,'bias':True}
conv_param_list = [conv_param_1,conv_param_2,conv_param_3,conv_param_4,conv_param_5,conv_param_6,conv_param_7,conv_param_8]

A_net = DRKN_model.RFF_Cov_net(conv_param_list,batch_size,h_dim,device,kernel_approximation)
A_net = A_net.to(device)
A_optimizer = torch.optim.Adam(A_net.parameters(),lr=learning_rate )


def main():
    for e in range(epochs):
        train_test.train_DRKN(e,A_net,A_optimizer,train_loader,'CIFAR10' )
        train_test.test_DRKN(A_net,test_loader,'CIFAR10')
        

if __name__ == '__main__':
    main()
